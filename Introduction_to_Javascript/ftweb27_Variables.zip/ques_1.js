var name = "Abhijeet";
var school = "Masai school";
const roll_no = fw27_022;
const maths = 90;
const science = 88;
const history = 94;
console.log("Name :",name);
console.log("School :",school);
console.log("Roll number :",roll_no);
console.log("Maths :",maths);
console.log("History ",history);
console.log("Sci