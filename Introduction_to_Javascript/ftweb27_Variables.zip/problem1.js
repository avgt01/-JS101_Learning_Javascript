let x=10;

if (x%3==0){
  console.log("the number is divisible by 3");
}
else{
  console.log("the number is not divisible by 3")
}