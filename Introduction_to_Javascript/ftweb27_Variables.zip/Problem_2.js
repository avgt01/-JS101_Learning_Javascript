let name = "Abhijeet Kumar Roushan";
console.log(name);

let father_name = "choudhary";
console.log(father_name);

let mother_name= "sunita";
console.log(mother_name);