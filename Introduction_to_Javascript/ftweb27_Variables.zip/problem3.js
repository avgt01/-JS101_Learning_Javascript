let a= 3;
let b= 55;

if(a>b){
  console.log("a is greater than b");
}
else if(b>a){
  console.log("b is greater than a");
}
else{
  console.log("they are same");
}