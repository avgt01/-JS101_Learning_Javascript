let stored = "avg"
let stored_pass="abc"
let username= "avgt"
let userpassword="abc"

if(stored==username)
{
  if(stored_pass==userpassword){
    console.log("you can login")
  }
  else{
    console.log("wrong password!")
  }
}
else{
  console.log("invalid username")
}