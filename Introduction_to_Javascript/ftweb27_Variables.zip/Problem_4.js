
let name = "Abhijeet";
let school= "Masai school";
let grade = 12;
let section= "f";
let rollno= 22;
let maths= 12;
let chemistry= 15;
let physics=22;

console.log("___________  ~𝑅𝑒𝑝𝑜𝑟𝑡 𝐶𝑎𝑟𝑑~ _______________");


console.log("|                                         |");
console.log("|", "Name:", name,"                         |");
console.log("|_________________________________________|");
console.log("|", "School:", school,"                   |");
console.log("|_________________________________________|");
console.log("|", "Grade:", grade,"                              |");
console.log("|_________________________________________|");
console.log("|", "Section:", section,"                             |");
console.log("|_________________________________________|");
console.log("|", "Roll number:",rollno,"                        |");
console.log("|_________________________________________|");
console.log("|", "Maths:", maths,"                              |");
console.log("|_________________________________________|");
console.log("|", "Chemistry:", chemistry,"                          |");
console.log("|_________________________________________|");
console.log("|", "Physics:", physics,"                            |");
console.log("|_________________________________________|");
console.log("|                                         |");
console.log("|                                         |");
console.log("| Remarks: You've failed miserably.       |");
console.log("|                                         |");
console.log("|                                         |");
console.log("|_________________________________________|");