let shop = "iphone";
let mydream = "oneplus";

// if(shop == mydream){
//   console.log("Buy the phone");
// }
// else{
//   console.log("I'll not buy the phone");
// }
(shop == mydream) ? console.log("Buy the phone") : console.log("I'll not buy the phone"); //this line is called ternary operator//