let traffic_light = "black";

if(traffic_light=="green"){
  console.log("you are good to go")
}
else if(traffic_light=="yellow"){
  console.log("be ready");
}
else if(traffic_light=="red"){
  console.log("STOP");
}
else {
  console.log("ERROR!")
}