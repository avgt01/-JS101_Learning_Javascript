let a = 20;
let b = 4;
console.log(a/b);